package com.smartpay.soundbox.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "soundbox_preferences")

data class SoundBoxSettings(
    val displayLanguage: String = "en",
    val announcementLanguage: String = "ta", // Tamil default
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val soundChimeEnabled: Boolean = true,
    val isDemoModeActive: Boolean = false,
    val isDarkMode: Boolean = true
)

class SoundBoxPreferences(private val context: Context) {
    val settingsFlow: Flow<SoundBoxSettings> = context.dataStore.data.map { preferences ->
        SoundBoxSettings(
            displayLanguage = preferences[stringPreferencesKey("display_language")] ?: "en",
            announcementLanguage = preferences[stringPreferencesKey("announcement_language")] ?: "ta",
            speechRate = preferences[floatPreferencesKey("speech_rate")] ?: 1.0f,
            speechPitch = preferences[floatPreferencesKey("speech_pitch")] ?: 1.0f,
            soundChimeEnabled = preferences[booleanPreferencesKey("sound_chime")] ?: true,
            isDarkMode = preferences[booleanPreferencesKey("dark_mode")] ?: true
        )
    }
}