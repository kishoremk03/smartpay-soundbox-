package com.smartpay.soundbox.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.smartpay.soundbox.data.AppDatabase
import com.smartpay.soundbox.data.PaymentTransaction
import kotlinx.coroutines.*

class SmartPayNotificationListenerService : NotificationListenerService() {
    private val scope = CoroutineScope(Dispatchers.IO)
    private lateinit var ttsManager: SmartPayTtsManager

    override fun onCreate() {
        super.onCreate()
        ttsManager = SmartPayTtsManager(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val extras = sbn?.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()

        val result = TransactionParser.parse(title, text) ?: return
        scope.launch {
            val db = AppDatabase.getDatabase(applicationContext)
            db.transactionDao().insertTransaction(
                PaymentTransaction(
                    amount = result.amount,
                    sourcePackage = sbn.packageName ?: "com.phonepe.app",
                    sourceAppName = "UPI Payment",
                    rawNotificationText = "$title: $text",
                    detectionStatus = "Detected — Not Bank Verified"
                )
            )
        }
    }
}