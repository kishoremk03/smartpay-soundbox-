package com.smartpay.soundbox.service

import java.util.regex.Pattern

data class ParsedPaymentResult(
    val amount: Double,
    val senderName: String?,
    val upiReference: String?,
    val isCredit: Boolean
)

object TransactionParser {
    private val AMOUNT_PATTERN = Pattern.compile(
        """(?:₹|Rs\.?|INR)\s*([0-9]{1,3}(?:,[0-9]{2,3})*(?:\.[0-9]{1,2})?|[0-9]+(?:\.[0-9]{1,2})?)""",
        Pattern.CASE_INSENSITIVE
    )

    private val CREDIT_KEYWORDS = listOf("received", "credited", "added", "accepted", "பெறப்பட்டது", "प्राप्त")
    private val DEBIT_KEYWORDS = listOf("paid", "sent", "debited", "withdrawn")

    fun parse(title: String?, text: String?): ParsedPaymentResult? {
        val combined = "${title.orEmpty()} ${text.orEmpty()}".trim()
        if (combined.isEmpty()) return null

        val lower = combined.lowercase()
        if (DEBIT_KEYWORDS.any { lower.contains(it) } && !CREDIT_KEYWORDS.any { lower.contains(it) }) {
            return null // Reject outgoing payments
        }

        val matcher = AMOUNT_PATTERN.matcher(combined)
        if (!matcher.find()) return null

        val amountStr = matcher.group(1)?.replace(",", "") ?: return null
        val amount = amountStr.toDoubleOrNull() ?: return null

        return ParsedPaymentResult(amount = amount, senderName = "Customer", upiReference = null, isCredit = true)
    }
}