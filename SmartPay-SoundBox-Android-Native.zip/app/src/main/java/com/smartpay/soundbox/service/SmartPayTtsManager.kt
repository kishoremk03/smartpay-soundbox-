package com.smartpay.soundbox.service

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.util.Locale

class SmartPayTtsManager(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
        }
    }

    fun isLanguageAvailable(locale: Locale): Boolean {
        return (tts?.isLanguageAvailable(locale) ?: -1) >= TextToSpeech.LANG_AVAILABLE
    }

    fun speak(text: String, locale: Locale, speechRate: Float = 1.0f) {
        val engine = tts ?: return
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 180)
        } catch (_: Exception) {}

        engine.language = if (isLanguageAvailable(locale)) locale else Locale.ENGLISH
        engine.setSpeechRate(speechRate)
        engine.speak(text, TextToSpeech.QUEUE_ADD, Bundle(), "TTS_${System.currentTimeMillis()}")
    }
}