package com.smartpay.soundbox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.smartpay.soundbox.data.AppDatabase
import com.smartpay.soundbox.service.SmartPayTtsManager
import com.smartpay.soundbox.ui.DashboardScreen
import com.smartpay.soundbox.ui.theme.SmartPaySoundBoxTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SmartPaySoundBoxTheme {
                // Jetpack Compose entry point with Material 3
            }
        }
    }
}