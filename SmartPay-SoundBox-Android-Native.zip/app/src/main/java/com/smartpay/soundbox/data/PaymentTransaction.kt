package com.smartpay.soundbox.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a payment transaction detected via Android notification listener.
 * Strictly labelled as "Detected — Not Bank Verified".
 */
@Entity(tableName = "transactions")
data class PaymentTransaction(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val amount: Double,
    val sourcePackage: String,
    val sourceAppName: String,
    val senderName: String? = null,
    val upiReference: String? = null,
    val rawNotificationText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val detectionStatus: String = "Detected — Not Bank Verified",
    val isBankVerified: Boolean = false,
    val isSampleDemo: Boolean = false
)