# SmartPay Sound Box Android Project
Instructions to build APK directly from your Android phone without a computer using GitHub Actions or Termux.